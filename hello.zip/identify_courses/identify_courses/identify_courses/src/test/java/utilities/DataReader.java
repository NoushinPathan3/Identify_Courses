package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.*;

public class DataReader {


    public static List<HashMap<String, String>> getData(String filePath, String sheetName) throws IOException {

        List<HashMap<String, String>> myData = new ArrayList<>();

        FileInputStream file = new FileInputStream(filePath);
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheet(sheetName);

        int totalRows = sheet.getLastRowNum();
        XSSFRow headerRow = sheet.getRow(0);

        DataFormatter formatter = new DataFormatter();

        for (int i = 1; i <= totalRows; i++) {

            XSSFRow currentRow = sheet.getRow(i);
            HashMap<String, String> currentHash = new HashMap<>();

            for (int j = 0; j < headerRow.getLastCellNum(); j++) {

                String key = formatter.formatCellValue(headerRow.getCell(j));

                String value = "";
                if (currentRow != null && currentRow.getCell(j) != null) {
                    value = formatter.formatCellValue(currentRow.getCell(j));
                }

                currentHash.put(key, value);
            }

            myData.add(currentHash);
        }


        workbook.close();
        file.close();

        return myData;
    }
}
