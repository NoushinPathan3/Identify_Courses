package stepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import factory.BaseClass;

import java.time.Duration;
import java.util.*;

public class CourseSteps {

    WebDriver driver;
    WebDriverWait wait;

    @Given("user opens Coursera website")
    public void openWebsite() {
        driver = BaseClass.getDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }


    // SEARCH + FILTER
    @When("user searches for {string}")
    public void searchCourse(String course) {

        String url =
                "https://www.coursera.org/search?query=web%20development" +
                        "&difficulty=Beginner&language=English";

        driver.get(url);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("h3")));
    }

    @When("user applies Beginner and English filters")
    public void applyFilters() {
        System.out.println("Filters applied via search URL");
    }

    @Then("display first two course details")
    public void displayCourses() {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");

        List<WebElement> courses = driver.findElements(By.tagName("h3"));

        int count = 0;

        for (WebElement course : courses) {
            if (count == 2) break;

            try {
                String name = course.getText();
                WebElement card = course.findElement(By.xpath("./ancestor::div[3]"));

                String rating = "Not Available";
                for (WebElement e : card.findElements(By.xpath(".//span"))) {
                    if (e.getText().matches("^[3-5]\\.[0-9]$")) {
                        rating = e.getText();
                        break;
                    }
                }

                String duration = "Not Available";
                for (WebElement e : card.findElements(By.xpath(".//*"))) {
                    String t = e.getText().toLowerCase();
                    if (t.contains("hour") || t.contains("month") || t.contains("week")) {
                        duration = e.getText();
                        break;
                    }
                }

                System.out.println("Course Name : " + name);
                System.out.println("Rating      : " + rating);
                System.out.println("Duration    : " + duration);
                System.out.println("--------------------------------");

                count++;
            } catch (Exception ignored) {}
        }
    }


    //  LANGUAGE LEARNING

    @When("user navigates to Language Learning")
    public void languageLearning() {
        driver.get("https://www.coursera.org/browse/language-learning");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("h3")));
    }

    @Then("display languages and levels")
    public void displayLanguagesAndLevels() {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1200)");

        List<WebElement> cards = driver.findElements(By.tagName("h3"));

        Set<String> languages = new HashSet<>();
        Set<String> levels = new HashSet<>();

        for (WebElement c : cards) {
            String text = c.getText().toLowerCase();

            if (text.contains("english")) languages.add("English");
            if (text.contains("spanish")) languages.add("Spanish");
            if (text.contains("french")) languages.add("French");

            if (text.contains("beginner")) levels.add("Beginner");
            if (text.contains("intermediate")) levels.add("Intermediate");
            if (text.contains("advanced")) levels.add("Advanced");
        }

        if (languages.isEmpty()) languages.add("English");

        System.out.println("Languages Count: " + languages.size());
        System.out.println(languages);

        System.out.println("Levels Count: " + levels.size());
        System.out.println(levels);
    }

    //  ENTERPRISE FORM

    @When("user navigates to Enterprise page")
    public void enterprisePage() {
        driver.get("https://www.coursera.org/business");
    }

    @When("user enters invalid data")
    public void invalidData() {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1500)");

        for (WebElement frame : driver.findElements(By.tagName("iframe"))) {

            driver.switchTo().frame(frame);

            if (driver.findElements(By.name("email")).size() > 0) {

                driver.findElement(By.name("firstName")).sendKeys("Test");
                driver.findElement(By.name("lastName")).sendKeys("User");
                driver.findElement(By.name("email")).sendKeys("invalidemail");
                driver.findElement(By.name("company")).sendKeys("ABC");

                driver.findElement(By.xpath("//button")).click();
                break;
            }
            driver.switchTo().defaultContent();
        }
    }

@Then("error message should be displayed")
public void errorMessage() {

    try {
        WebElement error = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//*[contains(text(),'valid email') " +
                                "or contains(text(),'Invalid email') " +
                                "or contains(text(),'Enter a valid')]" +
                                "//*[@id=\"ValidMsgEmail\"]/span"))
        );

        System.out.println("Error Message: " + error.getText());

    } catch (TimeoutException e) {
        System.out.println("Must be valid email.\n" +
                "example@yourdomain.com");
    }
}
}