package hooks;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import factory.BaseClass;
import io.cucumber.java.*;

public class Hooks {

    WebDriver driver;
    static boolean screenshotTaken = false;

    @Before
    public void setup() throws IOException {
        driver = BaseClass.initializeBrowser();
    }

    @After
    public void tearDown() {
        BaseClass.tearDown();
    }

    @After
    public void captureSingleScreenshot(Scenario scenario) {

        if (!screenshotTaken) {
            try {
                TakesScreenshot ts = (TakesScreenshot) driver;

                File src = ts.getScreenshotAs(OutputType.FILE);
                String screenshotPath =
                        System.getProperty("Screenshots.dir") + "embedded.png";

                FileUtils.copyFile(src, new File(screenshotPath));

                byte[] bytes = ts.getScreenshotAs(OutputType.BYTES);
                scenario.attach(bytes, "image/png", "embedded");

                screenshotTaken = true;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}